public class p15
{
    public static void main(String[] args) 
    {
         
        System.out.println("Here is your pattern....!!!");
         
        for (int i = 1; i <= 5; i++) 
        { 
            for (int j = 5; j >= i; j--)
            {
                System.out.print(j+" ");
            }
             
            System.out.println();
        }
         
    }   
}
