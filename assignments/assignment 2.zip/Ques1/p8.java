public class p8
{
    public static void main(String[] args)
    {
        System.out.println("** Printing the pattern... **");

       for (int i = 5; i >= 1; i--)
        {
            
            for (int j = 0; j < i; j++)
            {
                System.out.print(" ");
            }

            for (int k = i; k <=5; k++)
            {
                System.out.print(k + " ");
            }
            System.out.println();
        }

    }
}