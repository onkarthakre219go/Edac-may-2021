public class hfpyr2

{

    public static void main(String[] args)

    {

              

        for (int i= 0; i<= 6-1 ; i++)

        {

            for (int j=0; j <i; j++)

            {

                System.out.print("");

            }

            for (int k=i; k<=6-1; k++)
			{ 
			  System.out.print("*" + ""); 
			} 
			
			System.out.println(""); 
			
		}
	}
}

