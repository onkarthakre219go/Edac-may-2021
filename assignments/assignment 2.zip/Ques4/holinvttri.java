
public class holinvttri
{
    public static void main(String[] args)
    {
		int n=6;
           int i=n;
                int j;	
              do 
               {
                    
		     if(i==1 || i==n)
            {
             j=1;
             do
            {
     	         System.out.print("*");
				 
    		    }
				while(++j <=i);
                }
                  else
	    	    {
                    j=1;
                      do
                       {
                          if(j==1 || j==i)
                            System.out.print("*");
                              	else
                                  System.out.print(" ");
			  }while(++j<=i);
                     }
                            System.out.println();
                       
               }  while(--i>0);           
               
    }
}