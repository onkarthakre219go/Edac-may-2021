class pyr5
{
public static void main(String args[])
{
for(int i=1;i<=9;i++)
{
int n1=1;
int n2=8;
for(int j=9;j>=1;j--)
{
if(j>i) 
{
System.out.print(" ");
}
else
{
System.out.print(n1);
}
n1++;
}
for(int k=2;k<=i;k++)
{
System.out.print(n2);
n2--;
}
System.out.println();
}
}
}