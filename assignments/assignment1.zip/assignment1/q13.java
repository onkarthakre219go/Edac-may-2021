//13. Write a Java program to print the area and perimeter of a rectangle. 
public class q13
{
public static void main(String[] args)
 {
	    
        double Width = 5.6,Height = 8.5;
		System.out.println("Width="+Width);
		System.out.println("Height="+Height);
        double perimeter = 2 * (Height + Width);
        double area = Height * Width;
        System.out.println("Area is  5.6 * 8.5 .2f = " + area);
        System.out.println("Perimeter is 2 * (5.6 + 8.5) = " + perimeter);
        
 }
}