//5.WAP to accept an array and display it in reverse form


import java.util.Scanner;
class que5
{
public static void main(String args[])
{

Scanner sc =new Scanner(System.in);

System.out.println("How many number you want to Enter:");

int n=sc.nextInt();

int a[]=new int[n];

System.out.println("Enter your array numbers:");

for(int i=0;i<n;i++)
{
a[i]=sc.nextInt();
}
System.out.println("Above array number are in Reverse order now");

for(int j=n-1;j>=0;j--)
{
System.out.println(a[j]);
}
}
}









