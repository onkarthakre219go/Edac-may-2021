/*2. WAP to accept number from user(Scanner class) print table of it
	5*1=5
	5*2=10
	5*3=15
	5*4=20*/
	import java.util.Scanner;
	class que2
	{
	public static void main(String args[])
	{
	 Scanner sc=new Scanner(System.in);
	 System.out.println("Enter a number :");
	 int a=sc.nextInt();
	
	 for(int i=1;i<=4;i++)
	 {
	 System.out.println(a +"*" +i+ "="+(a*i));
	 }
	 }
	 }