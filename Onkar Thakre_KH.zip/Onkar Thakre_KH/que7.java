//WAP to illustrate example of typecasting
class que7
{
	
    public static void main(String[] args)
    {
        System.out.println("Windening:");
        int i = 100; 
        long l = i;
        float f = l; 
        System.out.println("Int value "+i);
        System.out.println("Long value "+l);
        System.out.println("Float value "+f);


        System.out.println("Narrowing:"); 
        double d = 100.04; 
        long a = (long)d;
        int b = (int)a; 
        System.out.println("Double value "+d);
        System.out.println("Long value "+a); 
        System.out.println("Int value "+b); 
    } 
}
