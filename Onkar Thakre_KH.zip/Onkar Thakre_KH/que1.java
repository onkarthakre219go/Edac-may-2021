//1. WAP to accept 2 numbers from Command line argument and perform its addition and display
class que1
{
      public static void main(String args[])
      {
            int x,y,s;
 
            x=Integer.parseInt(args[0]);
            y=Integer.parseInt(args[1]);
 
            s=x+y;
            System.out.println("sum of " + x + " and " + y +" is " +s);
      }
}